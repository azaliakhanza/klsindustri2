// const mysql = require('mysql2')

// const koneksi = mysql.createConnection({
//     host: 'localhost',
//     user: 'root',
//     password: '',
//     database: 'db_express_wikrama'
// })

module.exports = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'db_express_wikrama'
}

// koneksi.connect(function(err){
//     if(err) {
//         console.log('Database connection failed: ' + err);
//     } else {
//         console.log('connected to database');
//     }
// })

